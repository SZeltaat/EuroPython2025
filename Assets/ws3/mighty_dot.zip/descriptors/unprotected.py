"""Normal methods can be overridden."""


class Unprotected:
    """Class with a method."""

    def meth(self):
        """Do something."""
        print('called meth')
        return 42


def test():
    """Demonstrate."""
    unprotected = Unprotected()
    print('before:', unprotected.meth())
    unprotected.meth = 43
    print('after:', unprotected.meth)


if __name__ == '__main__':
    test()
