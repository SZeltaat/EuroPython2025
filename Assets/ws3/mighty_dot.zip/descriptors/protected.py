"""Protect methods from being overridden."""

import types


class Protector:
    """Descriptor that protects methods from overriding."""

    def __init__(self, meth, use_cache):
        self.meth = meth
        self.use_cache = use_cache

    def __get__(self, instance, cls):
        is_static_method = isinstance(self.meth, staticmethod)
        # no method binding if
        # * access via class --> instance is None or
        # * method is a classmethod --> instance is None or
        # * method is a static method
        if instance is None or is_static_method:
            return self.meth

        def bind_method():
            """Bind method to instance and print message."""
            print(f'binding {self.meth.__name__}')
            return types.MethodType(self.meth, instance)

        if self.use_cache:
            bound_meth = instance.__dict__.get(self.meth.__name__)
            if not bound_meth:
                bound_meth = bind_method()
                instance.__dict__[self.meth.__name__] = bound_meth
        else:
            bound_meth = bind_method()
        return bound_meth

    def __set__(self, instance, value):
        raise AttributeError('cannot set method')


def protect_methods(use_cache):
    """Class decorator to apply `Protector`."""

    def _protect_methods(cls):
        """Replace methods with descriptors."""
        for name, obj in cls.__dict__.items():
            if callable(obj):
                setattr(cls, name, Protector(obj, use_cache=use_cache))
        return cls

    return _protect_methods
