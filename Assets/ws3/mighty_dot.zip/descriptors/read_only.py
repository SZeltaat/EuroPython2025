"""Read only attributes."""


class WrongReadOnly:
    """Wrong: missing `_set__` that raises exception."""

    def __set_name__(self, owner, attr_name):
        self.attr_name = attr_name

    def __get__(self, instance, owner):
        return 42


class Wrong:
    """Use `WrongReadOnly`."""

    attr_wrong_ro = WrongReadOnly()


class RightReadOnly:
    """Right: `_set__` raises exception."""

    def __set_name__(self, owner, attr_name):
        self.attr_name = attr_name

    def __get__(self, instance, owner):
        return 42

    def __set__(self, instance, value):
        raise AttributeError(f'attribute "{self.attr_name}" is read-only')


class Right:
    """Use `RightReadOnly`."""

    attr_ro = RightReadOnly()
