"""Caching attributes."""

class Cached:
    """Cached attribute."""

    def __set_name__(self, owner, attr_name):
        self.attr_name = attr_name

    def __get__(self, instance, owner):
        if instance is None:
            raise ValueError
        print('doing expensive calculation at first access')
        # do your work here
        value = 42
        instance.__dict__[self.attr_name] = value
        return value


class WithCache:
    """`attr` is calculated only one."""

    attr = Cached()
