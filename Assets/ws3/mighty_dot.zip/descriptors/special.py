"""Specal methods are special."""


class Special:
    """Class with special method."""

    def __contains__(self, item):
        print('got', item)
        return True


def test():
    """Demonstarte how it works."""
    special = Special()
    print('before:', 'abc' in special)
    special.__contains__ = 43
    print('after:', 'abc' in special)


if __name__ == '__main__':
    test()
