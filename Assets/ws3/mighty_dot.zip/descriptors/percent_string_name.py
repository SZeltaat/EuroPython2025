"""Example for the Same-Name-Trick with string as attribute name."""


class Percent:
    """Descriptor for percent values between 0 and 100."""

    def __init__(self, attr_name):
        self.attr_name = attr_name

    def __set__(self, instance, value):
        if not 0 <= value <= 100:
            raise ValueError(f'Value must be between 0 and 100. Got: {value}.')
        instance.__dict__[self.attr_name] = value


class WithPercent:
    """Class with attribute between 0 and 100."""

    percent = Percent('percent')

    def __init__(self, percent):
        self.percent = percent
