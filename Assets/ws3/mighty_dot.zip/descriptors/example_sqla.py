"""Descriptor usage in SQLAlchemy.

Descriptors generate SQL code in the background when an attribute is
accessed.
"""

from sqlalchemy import create_engine
from sqlalchemy import inspect
from sqlalchemy.schema import Column
from sqlalchemy.orm import DeclarativeBase, Session
from sqlalchemy.types import Integer, String

engine = create_engine('sqlite+pysqlite:///:memory:')


class Base(DeclarativeBase):
    pass


class State(Base):
    __tablename__ = 'state'

    id = Column(Integer, primary_key=True)
    message = Column(String)


Base.metadata.create_all(engine)
