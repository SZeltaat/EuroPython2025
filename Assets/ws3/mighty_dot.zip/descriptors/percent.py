"""Example for the Same-Name-Trick."""


class Percent:
    """Descriptor for percent values between 0 and 100."""

    def __set_name__(self, owner, attr_name):
        self.attr_name = attr_name

    def __set__(self, instance, value):
        if not 0 <= value <= 100:
            raise ValueError(f'Value must be between 0 and 100. Got: {value}.')
        instance.__dict__[self.attr_name] = value


class WithPercent:
    """Class with attribute between 0 and 100."""

    percent = Percent()

    def __init__(self, percent):
        self.percent = percent
