"""A non data descriptor."""


class NonDataDescriptor:
    """Non data descriptor don't implement `__set__`."""

    def __init__(self):
        self.value = 0

    def __get__(self, instance, cls):
        print('non data descriptor __get__')
        return self.value + 10
