"""Use class decorator `protect_methods`."""

from protected import protect_methods


@protect_methods(use_cache=True)
class ProtectedCached:
    """Class with protected methods."""

    def meth1(self):
        """Test method 1."""
        print('called')
        return 42

    def meth2(self):
        """Test method 2."""
        print('called')
        return 142

    @staticmethod
    def func():
        """Provide a static method."""
        return 42

    @classmethod
    def cls_meth(cls):
        """Provide a class method."""
        return 42


@protect_methods(use_cache=False)
class ProtectedUncached:
    """Class with protected methods."""

    def meth1(self):
        """Test method 1."""
        print('called')
        return 42

    def meth2(self):
        """Test method 2."""
        print('called')
        return 142

    @staticmethod
    def func():
        """Provide a static method."""
        return 42

    @classmethod
    def cls_meth(cls):
        """Provide a class method."""
        return 42
