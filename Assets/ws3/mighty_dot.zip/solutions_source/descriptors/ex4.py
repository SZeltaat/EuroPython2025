"""Prices with VAT."""

#  pylint: disable-msg=too-few-public-methods


class Total:
    """Allow only positive values."""

    def __init__(self, rate=1.19):
        self.rate = rate

    def __get__(self, instance, cls):
        return round(instance.net * self.rate, 2)

    def __set__(self, instance, value):
        raise NotImplementedError('Cannot change value.')


class Price:
    """A price with VAT."""

    def __init__(self, net):
        self.net = net


class PriceGermany(Price):
    """A price with VAT for Germany."""

    total = Total(1.19)


class PriceDenmark(Price):
    """A price with VAT for Denmark."""

    total = Total(1.25)


class PriceLuxembourg(Price):
    """A price with VAT Luxembourg."""

    total = Total(1.17)


if __name__ == '__main__':

    def test():
        """Demonstrate how it works."""
        price_germany = PriceGermany(110)
        print('Germany', price_germany.total)

        price_denmark = PriceDenmark(110)
        print('Denmark', price_denmark.total)

        price_luxembourg = PriceLuxembourg(110)
        print('Luxembourg', price_luxembourg.total)

        # Try to set it.
        price_denmark.total = 120

    test()
