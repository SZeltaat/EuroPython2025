"""Person with an age."""

import datetime


class Person:
    """Person with an age."""

    def __init__(self, last_name: str, first_name: str,
                 birthday: datetime.date):
        self.first_name = first_name
        self.last_name = last_name
        assert birthday < datetime.date.today()
        self._birthday = birthday

    def _calc_age(self):
        """Calculate the age of a person."""
        today = datetime.date.today()
        birthday = self._birthday
        age = today.year - birthday.year
        if (today.month, today.day) < (birthday.month, birthday.day):
            age -= 1
        return age

    @property
    def rate(self):
        """Rate a person has to pay."""
        age = self._calc_age()
        if age < 18:
            return 'reduced'
        elif age < 65:
            return 'full'
        else:
            return 'senior'
