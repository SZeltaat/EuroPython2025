"""Property with decorators."""

import math


class Square:
    """A square using properties with decorators."""

    def __init__(self, side):
        self.side = side

    @property
    def area(self):
        """Area of the square calculated by squaring the side."""
        return self.side**2

    @area.setter
    def area(self, value):
        """Set side to square root of area."""
        self.side = math.sqrt(value)

    @area.deleter
    def area(self):
        """
        Don't allow deleting.

        Without this delete method Python
        would raise an `AttributeError`.
        """
        print("Can't delete the area.")


if __name__ == '__main__':

    def test():
        """A small test."""
        square = Square(5)
        print('area:', square.area)
        print('set area')
        square.area = 10
        print('area:', square.area)
        print('side:', square.side)
        print('try to delete')
        del square.area
        print('area:', square.area)
        print('doc:', Square.area.__doc__)

    test()
