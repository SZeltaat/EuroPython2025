"""Property with function."""

import math


class Square:
    """A square using properties with decorators."""

    def __init__(self, side):
        self.side = side

    def my_get(self):
        """Area of the square calculated by squaring the side."""
        return self.side**2

    def my_set(self, value):
        """Set side to square root of area."""
        self.side = math.sqrt(value)

    def my_del(self):
        """
        Don't allow deleting.

        Without this  delete method Python
        would raise an `AttributeError`.
        """
        print("Can't delete the area.")

    area = property(fget=my_get, fset=my_set, fdel=my_del, doc=my_get.__doc__)


if __name__ == '__main__':

    def test():
        """A small test."""
        square = Square(5)
        print('area:', square.area)
        print('set area')
        square.area = 10
        print('area:', square.area)
        print('side:', square.side)
        print('try to delete')
        del square.area
        print('area:', square.area)
        print('doc:', Square.area.__doc__)

    test()
