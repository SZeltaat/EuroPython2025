"""Person with an age."""

import datetime


class Person:
    """Person with an age."""

    def __init__(self, last_name: str, first_name: str,
                 birthday: datetime.date):
        self.first_name = first_name
        self.last_name = last_name
        assert birthday < datetime.date.today()
        self.birthday = birthday

    def get_age(self):
        """Calculate the age of a person."""
        today = datetime.date.today()
        birthday = self.birthday
        age = today.year - birthday.year
        if (today.month, today.day) < (birthday.month, birthday.day):
            age -= 1
        return age
