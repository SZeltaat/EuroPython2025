"""Use a decorator to allow nested properties."""

import math


def nested_property(func):
    """Make defining properties simpler."""
    names = func()
    # We want the docstring from the decorated function.
    # If we do not set `doc, we get the docstring from `fget`.
    names['doc'] = func.__doc__
    return property(**names)


class Square:
    """A square using properties with decorators."""

    def __init__(self, side):
        self.side = side

    @nested_property
    def area():
        """Area of the square calculated by squaring the side."""

        def fget(self):
            """
            Calculate the area of the square.

            This happens when the attribute is accessed.
            """
            return self.side * self.side

        def fset(self, value):
            """Set side to square root of area."""
            self.side = math.sqrt(value)

        def fdel(self):
            """
            Don't allow deleting.

            Without this  delete method Python
            would raise an `AttributeError`.
            """
            print("Can't delete the area.")

        return locals()


if __name__ == '__main__':

    def test():
        """A small test."""
        square = Square(5)
        print('area:', square.area)
        print('set area')
        square.area = 10
        print('area:', square.area)
        print('side:', square.side)
        print('try to delete')
        del square.area
        print('area:', square.area)
        print('doc:', Square.area.__doc__)

    test()
